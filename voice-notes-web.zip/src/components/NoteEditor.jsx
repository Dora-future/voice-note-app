import React, { useEffect, useMemo, useState } from 'react'
import { useSpeechToText } from '../hooks/useSpeechToText'

export default function NoteEditor({ note, onChange, onNew, onDelete }){
  const { supported, listening, interim, start, stop } = useSpeechToText()
  const [tagInput, setTagInput] = useState('')

  useEffect(() => {
    const handler = (e) => {
      onChange({ ...note, content: (note.content + ' ' + e.detail).trim(), updatedAt: Date.now() })
    }
    window.addEventListener('speech-final', handler)
    return () => window.removeEventListener('speech-final', handler)
  }, [note, onChange])

  const addTag = () => {
    const t = tagInput.trim()
    if(!t) return
    const tags = Array.from(new Set([...(note.tags||[]), t]))
    onChange({ ...note, tags, updatedAt: Date.now() })
    setTagInput('')
  }

  const removeTag = (t) => {
    const tags = (note.tags||[]).filter(x => x !== t)
    onChange({ ...note, tags, updatedAt: Date.now() })
  }

  return (
    <div className="editor">
      <div className="toolbar">
        <button className="btn primary" onClick={onNew}>+ New</button>
        <button className="btn" onClick={listening ? stop : start} disabled={!supported}>
          {supported ? (listening ? 'Stop Dictation' : 'Start Dictation') : 'Dictation not supported'}
        </button>
        {interim && <span style={{fontSize:12, opacity:0.8}}>…{interim}</span>}
        <div style={{flex:1}} />
        <input className="tag" placeholder="add tag…" value={tagInput} onChange={e=>setTagInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&addTag()} />
        <button className="btn" onClick={addTag}>Add Tag</button>
        <button className="btn danger" onClick={() => onDelete(note.id)}>Delete</button>
      </div>
      <div className="content">
        <input
          className="title-input"
          placeholder="Note title…"
          value={note.title}
          onChange={(e)=>onChange({ ...note, title: e.target.value, updatedAt: Date.now() })}
        />
        <textarea
          className="textarea"
          placeholder="Start typing or use the mic…"
          value={note.content}
          onChange={(e)=>onChange({ ...note, content: e.target.value, updatedAt: Date.now() })}
        />
        <div style={{marginTop:8}}>
          {(note.tags||[]).map(t => (
            <span key={t} className="tag-pill" onClick={()=>removeTag(t)} title="Remove tag">{t} ✕</span>
          ))}
        </div>
      </div>
    </div>
  )
}
