const KEY = 'voice_notes_v1'

export function loadNotes(){
  const raw = localStorage.getItem(KEY)
  if(!raw) return []
  try{ return JSON.parse(raw) }catch{ return [] }
}

export function saveNotes(notes){
  localStorage.setItem(KEY, JSON.stringify(notes))
}

export function exportNotes(notes){
  const blob = new Blob([JSON.stringify(notes, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = 'notes-export.json'
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export async function importNotes(setNotes){
  return new Promise((resolve) => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'application/json'
    input.onchange = async () => {
      const file = input.files[0]
      const text = await file.text()
      try{
        const data = JSON.parse(text)
        setNotes(data)
        saveNotes(data)
        resolve(true)
      }catch{
        alert('Invalid JSON file')
        resolve(false)
      }
    }
    input.click()
  })
}
